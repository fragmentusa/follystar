# Folly Stars Telegram bot

## Install
Python 3.10+ recommended.

```bash
python -m venv .venv
# Windows:
.venv\Scripts\activate
# macOS/Linux:
source .venv/bin/activate

pip install -r requirements.txt
```

Copy `.env.example` to `.env` and fill in:
- BOT_TOKEN: token from @BotFather
- ADMIN_ID: your numeric Telegram user ID
- REVIEWS_URL: your reviews channel URL

Run:
```bash
python bot.py
```

## Included
- Ukrainian main menu
- Profile with registration date and completed-star statistics
- Calculator both directions at 0.78 UAH per star
- Support requests forwarded to admin
- Reviews link
- Gifts and Premium marked temporarily unavailable
- Order creation and Telegram Stars (XTR) invoice
- Admin approve/reject buttons
- `/done ORDER_ID` marks a delivered order complete and updates profile stats

## Important
- Digital goods sold inside Telegram bots must use Telegram Stars (XTR), not direct card checkout.
- The invoice price mapping in this starter is a sample (`1 XTR per ordered star`). Review your commercial pricing and Telegram requirements before launch.
- Fragment delivery is NOT connected in this starter. Admin approval moves the order to processing; you must actually fulfill it through Fragment, then run `/done ORDER_ID`.
- Do not share your BotFather token, account session, cookies, seed phrase, or wallet recovery phrase.
