import asyncio
import os
import sqlite3
import uuid
from datetime import datetime, timezone

from aiogram import Bot, Dispatcher, F
from aiogram.filters import CommandStart, Command
from aiogram.types import (
    Message, CallbackQuery, InlineKeyboardMarkup, InlineKeyboardButton,
    ReplyKeyboardMarkup, KeyboardButton, LabeledPrice, PreCheckoutQuery
)
from aiogram.fsm.state import StatesGroup, State
from aiogram.fsm.context import FSMContext
from aiogram.fsm.storage.memory import MemoryStorage
from dotenv import load_dotenv

load_dotenv()

BOT_TOKEN = os.getenv("BOT_TOKEN", "").strip()
ADMIN_ID = int(os.getenv("ADMIN_ID", "0"))
REVIEWS_URL = os.getenv("REVIEWS_URL", "https://t.me/").strip()
RATE_UAH = 0.78
DB_PATH = os.getenv("DB_PATH", "folly_stars.sqlite3")

if not BOT_TOKEN or not ADMIN_ID:
    raise RuntimeError("Заповни BOT_TOKEN та ADMIN_ID у файлі .env")

bot = Bot(BOT_TOKEN)
dp = Dispatcher(storage=MemoryStorage())


def db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn


def init_db():
    with db() as con:
        con.execute("""
        CREATE TABLE IF NOT EXISTS users (
            user_id INTEGER PRIMARY KEY,
            username TEXT,
            registered_at TEXT NOT NULL,
            stars_bought INTEGER DEFAULT 0,
            premium_months INTEGER DEFAULT 0
        )""")
        con.execute("""
        CREATE TABLE IF NOT EXISTS orders (
            order_id TEXT PRIMARY KEY,
            user_id INTEGER NOT NULL,
            username TEXT,
            stars INTEGER NOT NULL,
            amount_uah REAL NOT NULL,
            status TEXT NOT NULL,
            created_at TEXT NOT NULL,
            telegram_charge_id TEXT
        )""")
        con.execute("""
        CREATE TABLE IF NOT EXISTS support (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            username TEXT,
            message TEXT NOT NULL,
            created_at TEXT NOT NULL
        )""")


def now():
    return datetime.now(timezone.utc).astimezone().strftime("%d.%m.%Y %H:%M")


def ensure_user(user):
    with db() as con:
        row = con.execute("SELECT user_id FROM users WHERE user_id=?", (user.id,)).fetchone()
        if row is None:
            con.execute(
                "INSERT INTO users(user_id, username, registered_at) VALUES(?,?,?)",
                (user.id, user.username, now())
            )
        else:
            con.execute("UPDATE users SET username=? WHERE user_id=?", (user.username, user.id))


def main_menu():
    return ReplyKeyboardMarkup(
        keyboard=[
            [KeyboardButton(text="⭐ Купити Stars"), KeyboardButton(text="👤 Мій профіль")],
            [KeyboardButton(text="🎁 Подарунки"), KeyboardButton(text="🧮 Порахувати")],
            [KeyboardButton(text="🛡️ Відгуки"), KeyboardButton(text="💎 Telegram Premium")],
            [KeyboardButton(text="☎️ Служба підтримки")]
        ],
        resize_keyboard=True
    )


def back_kb():
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="🔙 Назад", callback_data="back")]
    ])


def admin_order_kb(order_id):
    return InlineKeyboardMarkup(inline_keyboard=[
        [
            InlineKeyboardButton(text="✅ Схвалити", callback_data=f"approve:{order_id}"),
            InlineKeyboardButton(text="❌ Відхилити", callback_data=f"reject:{order_id}")
        ]
    ])


class Flow(StatesGroup):
    calc_stars = State()
    calc_uah = State()
    buy_stars = State()
    support_message = State()


@dp.message(CommandStart())
async def start(message: Message, state: FSMContext):
    await state.clear()
    ensure_user(message.from_user)
    await message.answer(
        "⭐ <b>Folly Stars</b>\n\nВітаємо у магазині Telegram Stars!\nОберіть потрібний розділ нижче.",
        reply_markup=main_menu(), parse_mode="HTML"
    )


@dp.message(F.text == "🧮 Порахувати")
async def calculator(message: Message, state: FSMContext):
    await state.clear()
    kb = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="⭐ Зірки → Гривні", callback_data="calc:stars")],
        [InlineKeyboardButton(text="💵 Гривні → Зірки", callback_data="calc:uah")],
        [InlineKeyboardButton(text="🔙 Назад", callback_data="back")]
    ])
    await message.answer("🧮 <b>Порахувати вартість</b>\n\n💰 Оберіть тип конвертації:", reply_markup=kb, parse_mode="HTML")


@dp.callback_query(F.data == "calc:stars")
async def calc_stars_start(call: CallbackQuery, state: FSMContext):
    await state.set_state(Flow.calc_stars)
    await call.message.edit_text("🧮 Введіть кількість зірок:", reply_markup=back_kb())
    await call.answer()


@dp.callback_query(F.data == "calc:uah")
async def calc_uah_start(call: CallbackQuery, state: FSMContext):
    await state.set_state(Flow.calc_uah)
    await call.message.edit_text("🧮 Введіть суму в гривнях:", reply_markup=back_kb())
    await call.answer()


@dp.message(Flow.calc_stars)
async def calc_stars_result(message: Message, state: FSMContext):
    try:
        amount = int(message.text.strip())
        if amount <= 0 or amount > 10_000_000:
            raise ValueError
    except (ValueError, AttributeError):
        await message.answer("Будь ласка, введіть ціле число більше нуля.")
        return
    total = amount * RATE_UAH
    await state.clear()
    await message.answer(
        f"🧮 <b>Результат конвертації:</b>\n\n⭐️ {amount:,} зірок = {total:,.2f} грн\n\n💎 Курс: 0.78 грн/⭐️".replace(",", " "),
        reply_markup=back_kb(), parse_mode="HTML"
    )


@dp.message(Flow.calc_uah)
async def calc_uah_result(message: Message, state: FSMContext):
    try:
        amount = float(message.text.strip().replace(",", "."))
        if amount <= 0 or amount > 100_000_000:
            raise ValueError
    except (ValueError, AttributeError):
        await message.answer("Будь ласка, введіть коректну суму в гривнях.")
        return
    stars = int(amount / RATE_UAH)
    await state.clear()
    await message.answer(
        f"🧮 <b>Результат конвертації:</b>\n\n💵 {amount:.2f} грн = {stars:,} зірок ⭐️\n\n💎 Курс: 0.78 грн/⭐️".replace(",", " "),
        reply_markup=back_kb(), parse_mode="HTML"
    )


@dp.message(F.text == "👤 Мій профіль")
async def profile(message: Message):
    ensure_user(message.from_user)
    with db() as con:
        row = con.execute("SELECT * FROM users WHERE user_id=?", (message.from_user.id,)).fetchone()
    username = f"@{row['username']}" if row["username"] else "Не вказано"
    text = (
        "👤 <b>Ваш профіль 🌟</b>\n\n"
        f"🆔 ID: <code>{row['user_id']}</code> 🔑\n\n"
        f"👤 Username: {username} 📛\n\n"
        f"🗓 Дата реєстрації: {row['registered_at']} ⏰\n\n"
        "⭐️ Рейтинг: 0 ✨\n\n"
        "🏆 Статус: 🥈 Активний Клієнт\n\n"
        "📊 Статистика покупок: 📈\n\n"
        f"⭐️ Зірок куплено: {row['stars_bought']} ✨\n\n"
        f"💎 Місяців Premium: {row['premium_months']} 🚀"
    )
    await message.answer(text, reply_markup=back_kb(), parse_mode="HTML")


@dp.message(F.text == "🛡️ Відгуки")
async def reviews(message: Message):
    kb = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="💬 Переглянути відгуки", url=REVIEWS_URL)],
        [InlineKeyboardButton(text="🔙 Назад", callback_data="back")]
    ])
    await message.answer(
        "💬 <b>Відгуки наших клієнтів</b>\n\n"
        "📢 Всі відгуки публікуються в нашому каналі!\n\n"
        "🌟 Переглянь що кажуть інші про наш сервіс",
        reply_markup=kb, parse_mode="HTML"
    )


@dp.message(F.text == "🎁 Подарунки")
@dp.message(F.text == "💎 Telegram Premium")
async def unavailable(message: Message):
    await message.answer("⏳ Цей розділ тимчасово недоступний.", reply_markup=back_kb())


@dp.message(F.text == "☎️ Служба підтримки")
async def support_start(message: Message, state: FSMContext):
    await state.set_state(Flow.support_message)
    await message.answer("✍️ Опишіть вашу проблему або питання:", reply_markup=back_kb())


@dp.message(Flow.support_message)
async def support_receive(message: Message, state: FSMContext):
    if not message.text:
        await message.answer("Надішліть, будь ласка, текстове повідомлення.")
        return
    ensure_user(message.from_user)
    with db() as con:
        cur = con.execute(
            "INSERT INTO support(user_id, username, message, created_at) VALUES(?,?,?,?)",
            (message.from_user.id, message.from_user.username, message.text, now())
        )
        ticket = cur.lastrowid
    username = f"@{message.from_user.username}" if message.from_user.username else "без username"
    await bot.send_message(
        ADMIN_ID,
        f"📩 <b>Нове звернення #{ticket}</b>\nКористувач: {username}\nID: <code>{message.from_user.id}</code>\n\n{message.text}",
        parse_mode="HTML"
    )
    await state.clear()
    await message.answer(
        "✅ <b>Запит надіслано!</b>\n\n⏳ Очікуйте відповіді від нашої команди підтримки",
        reply_markup=main_menu(), parse_mode="HTML"
    )


@dp.message(F.text == "⭐ Купити Stars")
async def buy_start(message: Message, state: FSMContext):
    await state.set_state(Flow.buy_stars)
    await message.answer(
        "⭐ <b>Купити Telegram Stars</b>\n\n"
        "Введіть кількість зірок (від 50).\n"
        "Курс для розрахунку: 0.78 грн за ⭐.",
        reply_markup=back_kb(), parse_mode="HTML"
    )


@dp.message(Flow.buy_stars)
async def buy_amount(message: Message, state: FSMContext):
    try:
        stars = int(message.text.strip())
        if stars < 50 or stars > 100_000:
            raise ValueError
    except (ValueError, AttributeError):
        await message.answer("Введіть ціле число від 50 до 100000.")
        return
    await state.update_data(stars=stars)
    await state.clear()
    amount_uah = stars * RATE_UAH
    order_id = uuid.uuid4().hex[:10].upper()
    payload = f"folly:{order_id}:{message.from_user.id}:{stars}"
    # Telegram Stars invoices use XTR. 1 XTR is the invoice amount in Telegram Stars.
    # This is a sample checkout mapping; set your actual XTR price policy before launch.
    xtr_amount = stars
    with db() as con:
        con.execute(
            "INSERT INTO orders(order_id,user_id,username,stars,amount_uah,status,created_at) VALUES(?,?,?,?,?,?,?)",
            (order_id, message.from_user.id, message.from_user.username, stars, amount_uah, "awaiting_payment", now())
        )
    await message.answer_invoice(
        title=f"Folly Stars — {stars} ⭐",
        description=f"Замовлення {order_id}. Оплата цифрового товару через Telegram Stars.",
        payload=payload,
        provider_token="",
        currency="XTR",
        prices=[LabeledPrice(label=f"{stars} Telegram Stars", amount=xtr_amount)]
    )


@dp.pre_checkout_query()
async def pre_checkout(pre_checkout_query: PreCheckoutQuery):
    await pre_checkout_query.answer(ok=True)


@dp.message(F.successful_payment)
async def successful_payment(message: Message):
    payment = message.successful_payment
    parts = payment.invoice_payload.split(":")
    if len(parts) != 4 or parts[0] != "folly":
        await message.answer("Не вдалося розпізнати замовлення. Зверніться до підтримки.")
        return
    _, order_id, user_id_s, stars_s = parts
    user_id, stars = int(user_id_s), int(stars_s)
    with db() as con:
        row = con.execute("SELECT status FROM orders WHERE order_id=?", (order_id,)).fetchone()
        if row is None or row["status"] != "awaiting_payment":
            await message.answer("Платіж отримано, але замовлення потребує перевірки адміністратором.")
            return
        con.execute(
            "UPDATE orders SET status='under_review', telegram_charge_id=? WHERE order_id=?",
            (payment.telegram_payment_charge_id, order_id)
        )
    await message.answer(
        f"✅ <b>Оплату отримано!</b>\n\n✍️ Замовлення: <code>{order_id}</code>\n\n"
        "⏳ Статус: На розгляді\n\n⌛ Час обробки: 15–70 хвилин",
        parse_mode="HTML", reply_markup=main_menu()
    )
    uname = f"@{message.from_user.username}" if message.from_user.username else "без username"
    await bot.send_message(
        ADMIN_ID,
        f"🆕 <b>Нове оплачене замовлення</b>\n\nID: <code>{order_id}</code>\n"
        f"Користувач: {uname}\nTelegram ID: <code>{user_id}</code>\n"
        f"Товар: {stars} ⭐\nСума за вашим курсом: {stars * RATE_UAH:.2f} грн\n"
        "Оплата: Telegram Stars (XTR)\nСтатус: На розгляді",
        parse_mode="HTML", reply_markup=admin_order_kb(order_id)
    )


@dp.callback_query(F.data.startswith("approve:"))
async def approve_order(call: CallbackQuery):
    if call.from_user.id != ADMIN_ID:
        await call.answer("Немає доступу.", show_alert=True)
        return
    order_id = call.data.split(":", 1)[1]
    with db() as con:
        row = con.execute("SELECT * FROM orders WHERE order_id=?", (order_id,)).fetchone()
        if row is None or row["status"] != "under_review":
            await call.answer("Замовлення не знайдено або вже оброблено.", show_alert=True)
            return
        con.execute("UPDATE orders SET status='approved_processing' WHERE order_id=?", (order_id,))
    await bot.send_message(
        row["user_id"],
        f"✅ <b>Замовлення схвалено!</b>\n\n✍️ ID: <code>{order_id}</code>\n\n"
        f"🗃 Товар: {row['stars']} зірок\n\n"
        "🚀 Ваше замовлення вже обробляється автоматично!",
        parse_mode="HTML"
    )
    await call.message.edit_reply_markup(reply_markup=None)
    await call.answer("Замовлення схвалено. Виконайте доставку через Fragment.")
    await call.message.answer(
        f"⚠️ Замовлення {order_id} схвалено. Доставка через Fragment поки виконується вручну. "
        "Після фактичної доставки позначте замовлення виконаним у базі."
    )


@dp.callback_query(F.data.startswith("reject:"))
async def reject_order(call: CallbackQuery):
    if call.from_user.id != ADMIN_ID:
        await call.answer("Немає доступу.", show_alert=True)
        return
    order_id = call.data.split(":", 1)[1]
    with db() as con:
        row = con.execute("SELECT * FROM orders WHERE order_id=?", (order_id,)).fetchone()
        if row is None or row["status"] != "under_review":
            await call.answer("Замовлення не знайдено або вже оброблено.", show_alert=True)
            return
        con.execute("UPDATE orders SET status='rejected' WHERE order_id=?", (order_id,))
    await bot.send_message(row["user_id"], f"❌ <b>Замовлення {order_id} відхилено.</b>\nЗверніться до служби підтримки.", parse_mode="HTML")
    await call.message.edit_reply_markup(reply_markup=None)
    await call.answer("Замовлення відхилено.")


@dp.callback_query(F.data == "back")
async def back(call: CallbackQuery, state: FSMContext):
    await state.clear()
    try:
        await call.message.delete()
    except Exception:
        pass
    await call.message.answer("⭐ Folly Stars\nОберіть потрібний розділ:", reply_markup=main_menu())
    await call.answer()


@dp.message(Command("done"))
async def admin_done(message: Message):
    if message.from_user.id != ADMIN_ID:
        return
    parts = (message.text or "").split()
    if len(parts) != 2:
        await message.answer("Використання: /done ORDER_ID")
        return
    order_id = parts[1].upper()
    with db() as con:
        row = con.execute("SELECT * FROM orders WHERE order_id=?", (order_id,)).fetchone()
        if row is None or row["status"] != "approved_processing":
            await message.answer("Замовлення не знайдено або воно не в обробці.")
            return
        con.execute("UPDATE orders SET status='completed' WHERE order_id=?", (order_id,))
        con.execute("UPDATE users SET stars_bought=stars_bought+? WHERE user_id=?", (row["stars"], row["user_id"]))
    await bot.send_message(row["user_id"], f"🎉 <b>Замовлення виконано!</b>\n\nID: <code>{order_id}</code>\n⭐ Доставлено: {row['stars']} зірок", parse_mode="HTML")
    await message.answer(f"✅ Замовлення {order_id} позначено як виконане.")


async def main():
    init_db()
    await dp.start_polling(bot)


if __name__ == "__main__":
    asyncio.run(main())
